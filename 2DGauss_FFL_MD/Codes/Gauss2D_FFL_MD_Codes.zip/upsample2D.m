% img=upsample2D(Rr,Rc,img0) 
%
%       Rr, Rc    Rates of upsampling in row and column, respectively
%       img0      original image
%       img       image after upsampling
%
%       A pixel in img0 is expanded into Rr*Rc pixels in img; and the 
%       sum of intensities of the Rr*Rc pixels in img is equal the 
%       intensity of the pixel in img0. 
%
% Yi Sun
% 10/7/2012; 02/04/2024


function img=upsample2D(Rr,Rc,img0) 

[Kx, Ky]=size(img0) ;
Nx=Rr*Kx ; Ny=Rc*Ky ; img=zeros(Nx,Ny) ;
for kx=1:Kx
  for ky=1:Ky
    img(Rr*(kx-1)+1:Rr*kx,Rc*(ky-1)+1:Rc*ky)=img0(kx,ky) ;
  end
end
img=img/(Rr*Rc) ; 

end

