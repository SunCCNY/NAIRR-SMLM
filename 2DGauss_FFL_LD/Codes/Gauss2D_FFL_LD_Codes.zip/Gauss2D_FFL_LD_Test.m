%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NAIRR-SMLM: Gauss2D_FFL_LD_Test.m 
% (1) Gaussian    - PSF
% (2) 2D          - emitter locations with random uniform distribution 
% (3) FFL         - frame-by-frame localization
% (4) LD          - low density
% (5) Test        - a data movie of 1000 frames is generated with 
%                   medium SNR are synthesized 
% (6) Location    - emitters are located on a helix 
% (7) Markov      - emitters are randomly activated frame by frame following 
%                   a Markov chain
%
% References
% [1] Y. Sun, "Markov chain models of emitter activations in single molecule 
% localization microscopy," Optics Express, vol. 32, no. 19, pp. 33779-33794, 
% Sept. 2024.
% [2] Y. Sun, "Localization precision of stochastic optical localization 
% nanoscopy using single frames," J. Biomed. Optics, vol. 18, no. 11, pp. 
% 111418-14, Oct. 2013.
% [3] Y. Sun, "Root mean square minimum distance as a quality metric for
% stochastic optical localization nanoscopy images," Sci. Reports, vol. 8, 
% no. 1, pp. 17211, Nov. 2018.
% [4] Y. Sun, "Information sufficient segmentation and signal-to-noise 
% ratio in stochastic optical localization nanoscopy," Optics Letters, 
% vol. 45, no. 21, pp. 6102-6105, Nov. 1, 2020. 
% 
% Yi Sun
% Electrical Engineering Department
% The City College of City University of New York
% E-mail: ysun@ccny.cuny.edu
% 11/24/2019, 02/19/2020, 04/01/2020, 12/18/2020, 1/1/2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
%% Emitter density: choose one of them
eD=80 ;                       % nm, adjacent emitter distance 
eDen=0.5 ;                    % Low - emitter density (emitters/um^2)
fprintf(1,'Density=%3.2f (emitters/um^2): \n',eDen) ; 

%% Intialization 
rng('default') ; 
key=0 ;                       % key for random number generators
key=key+floor(eDen) ; 
rng(key) ; 

%% Optical system 
na=1.40 ; 
lambda=723 ;                  % Alexa700 wavelength in nm
a=2*pi*na/lambda ; 
% 2D Gaussian PSF; sigma is estimated from Airy PSF
sigma=1.3238/a ;              % sigma=108.81; 2*sigma=217.61 (nm) 
FWHM=2*sqrt(2*log(2))*sigma ; % FWHM=256.22 (nm)

%% Frame 
Kx=64 ; Ky=64 ;               % frame size in pixel
Dx=100 ; Dy=100 ;             % pixel size of cammera in nm
Lx=Kx*Dx ; Ly=Ky*Dy ;         % FOV: [0,Lx]x[0,Ly]

%% Emitter intensity and signal to noise ratio
Dt=0.01 ;                     % second, time per frame (1/Dt is frame rate) 
Ih=300000 ;                   % average number of detected photons per emitter per second
DtIh=Dt*Ih ;                  % photon count per frame per emitter 
% Median SNR         
b=5 ;                         % mean of Poisson noise (autofluorescence) (photons/s/nm^2)
mu=5 ;                        % mean of Gaussian noise (photons/s/nm^2)
G=3 ;                         % variance of Gaussian noise (photons/s/nm^2)
betas=0.07912 ;               % [3]
beta=betas/sigma^2 ; 
rp=Ih/b ;                     % 60000
nup=beta*rp ; 
SPNR=10*log10(nup) ;          % -3.97 (dB)
rg=Ih/G ;                     % 100000
nug=beta*rg ; 
SGNR=10*log10(nug) ;          % -1.75 (dB)
r=rp*rg/(rp+rg) ;             % 37500 
nu=beta*r ; 
SNR=10*log10(nu) ;            % -6.01 (dB)
Coff=mu*Dt*Dx*Dy ;            % Coff=500 photons/pixel; Camera offset in effect

%% Emitter locations - ground truth
fprintf(1,'Emitter locations: \n') ;
M=600 ;
phi=0.1 ; beta=7+0.5*rand ;   % helix parameters xy1=zeros(2,M) ;
xy1=zeros(2,M) ; 
J=zeros(1,M) ; 
m=1 ; J(m)=2 ;                % 1st emitter locaiton
xy1(:,m)=[beta*J(m)*cos(phi*J(m)) ; beta*J(m)*sin(phi*J(m))] ; 
for m=2:M
  if mod(m,50)==0
    fprintf(1,'M=%3d m=%3d \n',M,m) ;
  end
  syms t0
  St=vpasolve((beta*t0*cos(phi*t0)-xy1(1,m-1))^2+(beta*t0*sin(phi*t0)-xy1(2,m-1))^2==eD^2,t0,J(m-1)+0.1) ;
  J(m)=St ;
  xy1(:,m)=[beta*J(m)*cos(phi*J(m)) ; beta*J(m)*sin(phi*J(m))] ;
end
phi_=2*pi*rand ;              % random initial position 
xy_=2*randn(2,1) ;  
xy=[[cos(phi_) -sin(phi_)] ; [sin(phi_) cos(phi_)]]*xy1+xy_ ; 
xy=xy+[Lx/2 ; Ly/2] ;         % adjust to frame center 
                              % ground truth emitter locaitons 

%% Emitter activations parameters: Continuous illumination, state 0, 1, 2 
t0=1.0 ;                  % mean of T0 in sec
p0=exp(-Dt/t0) ;          % 0.9900, probability to retain state 0 in Dt
t1=0.025 ;                % mean of T1 in sec
p1=exp(-Dt/t1) ;          % 0.6703, probability to retain state 1 in Dt
t=4.5 ;                   % mean of T 
p=exp(-Dt/t) ;            % 0.9978, probability being photoactivatable in Dt
% transition probabilities
r00=p0*p ;                % 0.9879, Trans. prob. from state 0 to 0
r10=(1-p0)*p ;            % 0.0099, Trans. prob. from state 0 to 1
r20=1-p ;                 % 0.0022, Trans. prob. from state 0 to 2
r01=(1-p1)*p ;            % 0.3289, Trans. prob. from state 1 to 0
r11=p1*p ;                % 0.6688, Trans. prob. from state 1 to 1
r21=1-p ;                 % 0.0022, Trans. prob. from state 1 to 2

%% Generate states of all emitters in data movie 
N=500 ;                   % number of frames in data movie
                          % Temporal resolution (TR): N*Dt=5 sec
[ca,p,h1]=emActMarkovContinue(t,t1,t0,Dt,N,M) ;
                          % h1=0.0697
a=(ca==1) ;               % a(m,n)=1 if activated; a(m,n)=0 otherwise  
                          % sum(sum(a')==0): # of emitters never activated 
Ma_=sum(a) ;              % number of activated emitters in nth frame
% compare formulas and estimates 
Np_=sum(sum(ca~=2))/M ;   % 295.82, average # of photoactivatable frames per emitter
Nae_=sum(Ma_)/M ;         % 8.98, average # of activated frames per emitter in movie
Na_=M*Nae_ ;              % 5386, total # of activated frames for all emitters in movie 
Maf_=sum(Ma_)/N ;         % 10.77, average number of activated emitters per frame

%% Stack activated emitters in each frame
xyActive=zeros(2,M,N) ;  % activated emitter locations in nth frame
for n=1:N
  if Ma_(n)>0
    k=0 ; 
    for m=1:M
      if a(m,n)
        k=k+1 ;
        xyActive(:,k,n)=xy(:,m) ;
      end
      if k==Ma_(n), break ; end
    end
  end
end

%% Generate test dataset
fprintf(1,'Generate a data movie: \n') ; 
for n=1:N
  if mod(n,10)==0||n==1
    fprintf(1,'Data frame: %d\n',n) ;
  end
  k=Ma_(n) ;
  % Generate and save a set of emitter locations - ground truth
  filename_xy=strcat('2DGauss_FFL_LD_Test_xy_',num2str(n),'.txt') ;
  xy2=xyActive(:,1:k,n)' ; 
  save(filename_xy,'-ascii','xy2') ;
  % Generate and save a data frame
  if k>0
    U=Gauss2D_Frame(sigma,Kx,Ky,Dx,Dy,Dt,Ih,b,mu,G,xy2') ;
  else
    U=zeros(Ky,Kx) ; 
  end
  U16=uint16(U) ;
  filename_Frame=strcat('2DGauss_FFL_LD_Test_Frame_',num2str(n),'.tif') ;
  imwrite(U16,filename_Frame) ; 
end

%% Verify 10th frame of test dataset
n=10 ; 
fprintf(1,'Show frame %d \n',n) ; 
% read emitter locations - ground truth
filename_xy=strcat('2DGauss_FFL_LD_Test_xy_',num2str(n),'.txt') ;
xy3=load(filename_xy,'-ascii')' ;
k=size(xy3,2) ;    % # of activated emitters
% read and save a data frame
filename_Frame=strcat('2DGauss_FFL_LD_Test_Frame_',num2str(n),'.tif') ;
U16=imread(filename_Frame); % read a frame
U=double(U16) ;

% show data frame 
wx=3*Kx/64 ; wy=3*Ky/64 ;     % 3 inch when Kx=64, or 450 pixels with dpi=150
dx=0.04 ; dy=0.04 ; 
PS=[dx/2 dy/2 wx-dx wy-dy] ;   % Positions of subfigures 
figure('Units','inches','Position',[3 2 wx wy],'Color',[1 1 1]) ;
subplot(1,1,1,'Units','inches','Position',PS) ;
show8bimage(U,'Yes','gray','No') ; 
axis off
filename_Frame=strcat('Fig2DGauss_FFL_LD_Test_Frame_',num2str(n)) ;
print(filename_Frame,'-dpng')

% show data frame plus emitters
figure('Units','inches','Position',[3 2 wx wy],'Color',[1 1 1]) ;
subplot(1,1,1,'Units','inches','Position',PS) ;
show8bimage(U,'Yes','gray','No') ; hold on
plot(xy(1,:)/Dx+0.5,xy(2,:)/Dy+0.5,'w.','MarkerSize',3.5) ;
plot(xy3(1,:)/Dx+0.5,xy3(2,:)/Dy+0.5,'r.','MarkerSize',3.5) ; 
axis off
filename_Frame=strcat('Fig2DGauss_FFL_LD_Test_Frame_',num2str(n),'_Emitters') ;
print(filename_Frame,'-dpng')


