%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NAIRR-SMLM: Gauss2D_FFL_LD_Train.m 
% (1) Gaussian    - PSF
% (2) 2D          - emitter locations with random uniform distribution 
% (3) FFL         - frame-by-frame localization
% (4) LD          - low density
% (5) Train       - a set of 500 training data frames with medium SNR are 
%                   synthesized 
%
% References
% [1] Y. Sun, "Localization precision of stochastic optical localization 
% nanoscopy using single frames," J. Biomed. Optics, vol. 18, no. 11, pp. 
% 111418-14, Oct. 2013.
% [2] Y. Sun, "Root mean square minimum distance as a quality metric for
% stochastic optical localization nanoscopy images," Sci. Reports, vol. 8, 
% no. 1, pp. 17211, Nov. 2018.
% [3] Y. Sun, "Information sufficient segmentation and signal-to-noise 
% ratio in stochastic optical localization nanoscopy," Optics Letters, 
% vol. 45, no. 21, pp. 6102-6105, Nov. 1, 2020. 
% 
% Yi Sun
% Electrical Engineering Department
% The City College of City University of New York
% E-mail: ysun@ccny.cuny.edu
% 11/24/2019, 02/19/2020, 04/01/2020, 12/18/2020, 12/23/2024
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
%% Emitter density: choose one of them
eDen=0.5 ;                   % Low - emitter density (emitters/um^2)
fprintf(1,'Density=%3.2f (emitters/um^2): \n',eDen) ; 

%% Intialization 
rng('default') ; 
key=0 ;                       % key for random number generators
key=key+floor(eDen) ; 
rng(key) ; 

%% Optical system 
na=1.40 ; 
lambda=723 ;                  % Alexa700 wavelength in nm
a=2*pi*na/lambda ; 
% 2D Gaussian PSF; sigma is estimated from Airy PSF
sigma=1.3238/a ;              % sigma=108.81; 2*sigma=217.61 (nm) 
FWHM=2*sqrt(2*log(2))*sigma ; % FWHM=256.22 (nm)

%% Frame 
Kx=32 ; Ky=32 ;               % frame size in pixel
Dx=100 ; Dy=100 ;             % pixel size of cammera in nm
Lx=Kx*Dx ; Ly=Ky*Dy ;         % FOV: [0,Lx]x[0,Ly]
M=fix(eDen*Lx*Ly/1e6) ;       % number of emitters: 5

%% Emitter intensity and signal to noise ratio
Dt=0.01 ;                     % second, time per frame (1/Dt is frame rate) 
Ih=300000 ;                   % average number of detected photons per emitter per second
DtIh=Dt*Ih ;                  % photon count per frame per emitter 
% Median SNR         
b=5 ;                         % mean of Poisson noise (autofluorescence) (photons/s/nm^2)
mu=5 ;                        % mean of Gaussian noise (photons/s/nm^2)
G=3 ;                         % variance of Gaussian noise (photons/s/nm^2)
betas=0.07912 ;               % [3]
beta=betas/sigma^2 ; 
rp=Ih/b ;                     % 60000
nup=beta*rp ; 
SPNR=10*log10(nup) ;          % -3.97 (dB)
rg=Ih/G ;                     % 100000
nug=beta*rg ; 
SGNR=10*log10(nug) ;          % -1.75 (dB)
r=rp*rg/(rp+rg) ;             % 37500 
nu=beta*r ; 
SNR=10*log10(nu) ;            % -6.01 (dB)
Coff=mu*Dt*Dx*Dy ;            % Coff=500 photons/pixel; Camera offset in effect

%% Generate training datasets
N=500 ;                       % number of data frames
for n=1:N
  if mod(n,10)==0||n==1
    fprintf(1,'Data frame: %d\n',n) ;
  end
  % Generate and save a set of emitter locations - ground truth
  xy=[Lx*rand(M,1) Ly*rand(M,1)] ;  % randomly uniformly distributed
  filename_xy=strcat('2DGauss_FFL_LD_Train_xy_',num2str(n),'.txt') ;
  save(filename_xy,'-ascii','xy') ;
  % Generate and save a data frame
  U=Gauss2D_Frame(sigma,Kx,Ky,Dx,Dy,Dt,Ih,b,mu,G,xy') ;
  U16=uint16(U) ;
  filename_Frame=strcat('2DGauss_FFL_LD_Train_Frame_',num2str(n),'.tif') ;
  imwrite(U16,filename_Frame) ; 
end

%% Verify 10th frame of training dataset
n=10 ; 
fprintf(1,'Show frame %d \n',n) ; 
% read emitter locations - ground truth
filename_xy=strcat('2DGauss_FFL_LD_Train_xy_',num2str(n),'.txt') ;
xy3=load(filename_xy,'-ascii')' ; 
k=size(xy3,2) ;    % # of activated emitters
% read and save a data frame
filename_Frame=strcat('2DGauss_FFL_LD_Train_Frame_',num2str(n),'.tif') ;
U16=imread(filename_Frame);   % read a frame
U=double(U16) ;

% show data frame 
wx=3*Kx/64 ; wy=3*Ky/64 ;     % 3 inch when Kx=64, or 450 pixels with dpi=150
dx=0.04 ; dy=0.04 ; 
PS=[dx/2 dy/2 wx-dx wy-dy] ;  % Positions of subfigures 
figure('Units','inches','Position',[3 2 wx wy],'Color',[1 1 1]) ;
subplot(1,1,1,'Units','inches','Position',PS) ;
show8bimage(U,'Yes','gray','No') ; 
axis off
filename_Frame=strcat('Fig2DGauss_FFL_LD_Train_Frame_',num2str(n)) ;
print(filename_Frame,'-dpng')

% show data frame plus emitters
figure('Units','inches','Position',[3 2 wx wy],'Color',[1 1 1]) ;
subplot(1,1,1,'Units','inches','Position',PS) ;
show8bimage(U,'Yes','gray','No') ; hold on
plot(xy3(1,:)/Dx+0.5,xy3(2,:)/Dy+0.5,'r.','MarkerSize',3.5) ; 
axis off
filename_Frame=strcat('Fig2DGauss_FFL_LD_Train_Frame_',num2str(n),'_Emitters') ;
print(filename_Frame,'-dpng')
