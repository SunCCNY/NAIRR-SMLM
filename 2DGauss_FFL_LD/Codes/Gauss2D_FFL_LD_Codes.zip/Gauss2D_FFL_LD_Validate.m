%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NAIRR-SMLM: Gauss2D_FFL_LD_Validate.m 
% (1) Gaussian    - PSF
% (2) 2D          - emitter locations with random uniform distribution 
% (3) FFL         - frame-by-frame localization
% (4) LD          - low density
% (5) Validate    - a set of validating data frames with medium SNR are 
%                   synthesized 
%
% References
% [1] Y. Sun, "Localization precision of stochastic optical localization 
% nanoscopy using single frames," J. Biomed. Optics, vol. 18, no. 11, pp. 
% 111418-14, Oct. 2013.
% [2] Y. Sun, "Root mean square minimum distance as a quality metric for
% stochastic optical localization nanoscopy images," Sci. Reports, vol. 8, 
% no. 1, pp. 17211, Nov. 2018.
% [3] Y. Sun, "Information sufficient segmentation and signal-to-noise 
% ratio in stochastic optical localization nanoscopy," Optics Letters, 
% vol. 45, no. 21, pp. 6102-6105, Nov. 1, 2020. 
% 
% Yi Sun
% Electrical Engineering Department
% The City College of City University of New York
% E-mail: ysun@ccny.cuny.edu
% 11/24/2019, 02/19/2020, 04/01/2020, 12/18/2020, 12/23/2024
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
%% Emitter density: choose one of them
eDen=0.5 ;                    % Low - emitter density (emitters/um^2)
N=50 ;                        % number of data frames

%% Intialization 
rng('default') ; 
key=0 ;                       % key for random number generators
key=key+floor(eDen) ; 
rng(key) ; 

%% Optical system 
na=1.40 ; 
lambda=723 ;                  % Alexa700 wavelength in nm
a=2*pi*na/lambda ; 
% 2D Gaussian PSF; sigma is estimated from Airy PSF
sigma=1.3238/a ;              % sigma=108.81; 2*sigma=217.61 (nm) 

%% Frame 
Kx=32 ; Ky=32 ;               % frame size in pixel
Dx=100 ; Dy=100 ;             % pixel size of cammera in nm
Lx=Kx*Dx ; Ly=Ky*Dy ;         % FOV: [0,Lx]x[0,Ly]
M=fix(eDen*Lx*Ly/1e6) ;       % number of emitters: 5

%% Emitter intensity and signal to noise ratio
Dt=0.01 ;                     % second, time per frame (1/Dt is frame rate) 
Ih=300000 ;                   % average number of detected photons per emitter per second
DtIh=Dt*Ih ;                  % photon count per frame per emitter 
% Median SNR         
b=5 ;                         % mean of Poisson noise (autofluorescence) (photons/s/nm^2)
mu=5 ;                        % mean of Gaussian noise (photons/s/nm^2)
G=3 ;                         % variance of Gaussian noise (photons/s/nm^2)
betas=0.07912 ;               % [3]
beta=betas/sigma^2 ; 
rp=Ih/b ;                     % 60000
rg=Ih/G ;                     % 100000
r=rp*rg/(rp+rg) ;             % 37500 
nu=beta*r ; 
SNR=10*log10(nu) ;            % -6.01 (dB)
Coff=mu*Dt*Dx*Dy ;            % Coff=500 photons/pixel; Camera offset in effect

%% generate datasets of xy and frames
fprintf(1,'Generate datasets. \n')
MN=M*N ;                      % total # of emitter activations in movie
v.id=zeros(MN,1) ;            % id
v.fn=zeros(MN,1) ;            % frame index
v.xy=zeros(MN,2) ;            % emitter coordinates
v.sg=sigma*ones(MN,1) ;       % sigma in nm
v.it=DtIh*ones(MN,1) ;        % intensity (photons)
v.os=Coff*ones(MN,1) ;        % offset 
v.bksd=(b+G)*ones(MN,1) ;     % standard deviation of background noise 
F=uint16(zeros(Ky,Kx,N)) ;    % all frames in movie
p=0 ; 
for n=1:N
  % Generate emitter locations of nth frame - ground truth
  xy=[Lx*rand(M,1) Ly*rand(M,1)] ;  % randomly uniformly distributed
  k=M ;                       % # of activated emitters in nth frame
  v.id(p+1:p+k)=(p+1:p+k)' ; 
  v.fn(p+1:p+k)=n ; 
  v.xy(p+1:p+k,:)=xy ;        % ground truth
  % Generate a data frame
  U=Gauss2D_Frame(sigma,Kx,Ky,Dx,Dy,Dt,Ih,b,mu,G,xy') ;
  F(:,:,n)=uint16(U) ;
  p=p+k ; 
end

%% Save validate datasets frame by frame
fprintf(1,'Save validate datasets frame by frame. \n')
p=0 ; 
for n=1:N
  k=0 ; 
  while p+k<MN && v.fn(p+k+1)==n
    k=k+1 ; 
  end
  if k>0
    % save emitter locations of nth frame 
    xy=v.xy(p+1:p+k,:) ; 
    filename_xy=strcat('2DGauss_FFL_LD_Validate_xy_',num2str(n),'.txt') ;
    save(filename_xy,'-ascii','xy') ;
    % save nth frame
    U16=F(:,:,n) ;
    filename_Frame=strcat('2DGauss_FFL_LD_Validate_Frame_',num2str(n),'.tif') ;
    imwrite(U16,filename_Frame) ;
  end
  p=p+k ;
end

%% Save validate datasets in DeepSTORM format
fprintf(1,'Save validate datasets in DeepSTORM format. \n')
% write dataset of emitter locations 
xy3=table(v.id,v.fn,v.xy(:,1),v.xy(:,2),v.sg,v.it,v.os,v.bksd, ...
  'VariableNames', {'Id','Frame','x (nm)','y (nm)','sigma (nm)', ...
  'Intensity (photons)','Offset (photons)','BkgSD (photons)'}) ;
writetable(xy3,'2DGauss_FFL_LD_Validate_xy.csv') ; 
% write data frame in DeepSTORM format
for n=1:N
  U16=F(:,:,n) ;
  if n==1
    imwrite(U16,'2DGauss_FFL_LD_Validate_Frame.tif','tif','WriteMode','overwrite','compression','none') ;
  else
    imwrite(U16,'2DGauss_FFL_LD_Validate_Frame.tif','tif','WriteMode','append','compression','none') ;
  end    
end
