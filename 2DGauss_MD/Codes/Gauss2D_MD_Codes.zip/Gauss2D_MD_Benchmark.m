%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NAIRR-SMLM: Gauss2D_MD_Benchmark.m 
% . Gaussian    - PSF
% . 2D          - 2D emitter locations 
% . MD          - medium density of emitters
% . Benchmark   - benchmark dataset 
% . Location    - emitters are located on a circle 
% . Markov      - emitters activated frame by frame by allowing a Markov chain 
% . Benchmark   - UGIA-F and UGIA-M estimators reconstruct SMLM images 
% . Evaluate    - by quality metric of root mean square minimum distance (RMSMD) 
%
% References
% [1] Y. Sun, "Spatiotemporal resolution as an information theoretical 
% property of stochastic optical localization nanoscopy," 2020 Quantitative 
% BioImaging Conf. (QBI2020), Oxford, UK, Jan. 6-9, 2020.
% [2] Y. Sun, "Markov chain models of emitter activations in single molecule 
% localization microscopy," Optics Express, vol. 32, no. 19, pp. 33779-33794, 
% Sept. 2024.
% [3] Y. Sun, "Localization precision of stochastic optical localization 
% nanoscopy using single frames," J. Biomed. Optics, vol. 18, no. 11, pp. 
% 111418-14, Oct. 2013.
% [4] Y. Sun, "Root mean square minimum distance as a quality metric for
% stochastic optical localization nanoscopy images," Sci. Reports, vol. 8, 
% no. 1, pp. 17211, Nov. 2018.
% [5] Y. Sun, "Information sufficient segmentation and signal-to-noise 
% ratio in stochastic optical localization nanoscopy," Optics Letters, 
% vol. 45, no. 21, pp. 6102-6105, Nov. 1, 2020. 
% 
% Yi Sun
% Electrical Engineering Department
% The City College of City University of New York
% E-mail: ysun@ccny.cuny.edu
% 11/24/2019, 04/01/2020, 12/18/2020, 12/23/2024, 1/24/2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
%% Emitter distance
% adjust eD and t0, t1, and t to control emitter density
eD=50 ;                       % emitter distance 
N=1000 ;                      % number of data frames

%% Intialization 
rng('default') ; 
key=0 ;                       % key for random number generators
key=key+floor(eD+N) ; 
rng(key) ; 

%% Optical system 
na=1.40 ; 
lambda=723 ;                  % Alexa700 wavelength in nm
a=2*pi*na/lambda ; 
% 2D Gaussian PSF; sigma is estimated from Airy PSF
sigma=1.3238/a ;              % sigma=108.81; 2*sigma=217.61 (nm) 

%% Frame 
Kx=64 ; Ky=64 ;               % frame size in pixel
Dx=100 ; Dy=100 ;             % pixel size of cammera in nm
Lx=Kx*Dx ; Ly=Ky*Dy ;         % FOV: [0,Lx]x[0,Ly]

%% Emitter intensity and signal to noise ratio
Dt=0.01 ;                     % second, time per frame (1/Dt is frame rate) 
Ih=300000 ;                   % average number of detected photons per emitter per second
DtIh=Dt*Ih ;                  % photon count per frame per emitter 
% Median SNR         
b=5 ;                         % mean of Poisson noise (autofluorescence) (photons/s/nm^2)
mu=5 ;                        % mean of Gaussian noise (photons/s/nm^2)
G=3 ;                         % variance of Gaussian noise (photons/s/nm^2)
betas=0.07912 ;               % [3]
beta=betas/sigma^2 ; 
rp=Ih/b ;                     % 60000
rg=Ih/G ;                     % 100000
r=rp*rg/(rp+rg) ;             % 37500 
nu=beta*r ; 
SNR=10*log10(nu) ;            % -6.01 (dB) [3]
Coff=mu*Dt*Dx*Dy ;            % Coff=500 photons/pixel; Camera offset in effect

%% Emitter locations on a circle - ground truth
fprintf(1,'Emitter locations. \n') ;
M=200 ;                       % # of emitters 
rd=eD/(2*sin(pi/M)) ;         % 1.59 um, radius 
theta=2*pi*(0:M-1)/M ; 
xy=[rd*cos(theta)+Lx/2 ; rd*sin(theta)+Ly/2] ; 

%% Emitter activations parameters: Continuous illumination, state 0, 1, 2 
t0=0.55 ;                     % mean of T0 in sec
p0=exp(-Dt/t0) ;              % 0.9820, probability to retain state 0 in Dt
t1=0.035 ;                     % mean of T1 in sec
p1=exp(-Dt/t1) ;              % 0.7515, probability to retain state 1 in Dt
t=10.0 ;                      % mean of T 
p=exp(-Dt/t) ;                % 0.9990, probability being photoactivatable in Dt
% transition probabilities
r00=p0*p ;                    % 0.9810, Trans. prob. from state 0 to 0
r10=(1-p0)*p ;                % 0.0180, Trans. prob. from state 0 to 1
r20=1-p ;                     % 0.0009995, Trans. prob. from state 0 to 2
r01=(1-p1)*p ;                % 0.2483, Trans. prob. from state 1 to 0
r11=p1*p ;                    % 0.7507, Trans. prob. from state 1 to 1
r21=1-p ;                     % 0.009995, Trans. prob. from state 1 to 2

%% Generate states of all emitters in data movie 
[ca,~,h1]=emActMarkovContinue(t,t1,t0,Dt,N,M) ;
                              % h1=0.0676
a=(ca==1) ;                   % a(m,n)=1 if activated; a(m,n)=0 otherwise  
                              % sum(sum(a')==0): # of emitters never activated 
a(:,N)=(sum(a,2)==0) ;        % make every emitter activated at least once
Ma_=sum(a) ;                  % number of activated emitters in nth frame
% compare formulas and estimates 
Np=sum(sum(ca~=2))/M ;        % 623.02, average # of photoactivatable frames per emitter
Nae=sum(Ma_)/M ;              % 42.60, average # of activated frames per emitter in movie
Na=M*Nae ;                    % 8520, total # of activated frames for all emitters in movie 
Maf=sum(Ma_)/N ;              % 8.52, average number of activated emitters per frame
Df=Maf/(Lx*Ly/1e6) ;          % 0.2080 average density of activated emitters per frame 
 
%% Stack activated emitters in each frame
xyActive=zeros(2,M,N) ;       % activated emitter locations in nth frame
ActiveId=zeros(M,N) ;         % id of activated emitters in nth frame
for n=1:N
  if Ma_(n)>0
    k=0 ; 
    for m=1:M
      if a(m,n)
        k=k+1 ;
        xyActive(:,k,n)=xy(:,m) ;
        ActiveId(k,n)=m ; 
      end
      if k==Ma_(n), break ; end
    end
  end
end

%% generate datasets of xy and frames
MN=sum(sum(a)) ;              % total # of emitter activations in movie
fprintf(1,'Generate datasets. \n')
v.No=zeros(MN,1) ;            % #
v.fn=zeros(MN,1) ;            % frame index
v.eId=zeros(MN,1) ;           % id of activated emitters
v.xy=zeros(MN,2) ;            % emitter coordinates
v.sg=sigma*ones(MN,1) ;       % sigma in nm
v.it=DtIh*ones(MN,1) ;        % intensity (photons)
v.os=Coff*ones(MN,1) ;        % offset 
v.bksd=(b+G)*ones(MN,1) ;     % standard deviation of background noise 
F=uint16(zeros(Ky,Kx,N)) ;    % all frames in movie
p=0 ; 
for n=1:N
  % Generate emitter locations of nth frame - ground truth
  k=Ma_(n) ;                  % # of activated emitters in nth frame
  if k>0
    xy2=xyActive(:,1:k,n)' ;
    v.No(p+1:p+k)=(p+1:p+k)' ;
    v.fn(p+1:p+k)=n ;
    v.eId(p+1:p+k)=ActiveId(1:k,n)' ;
    v.xy(p+1:p+k,:)=xy2 ;     % ground truth
    % Generate a data frame
    U=Gauss2D_Frame(sigma,Kx,Ky,Dx,Dy,Dt,Ih,b,mu,G,xy2') ;
    F(:,:,n)=uint16(U) ;
    p=p+k ; 
  end
end

%% Save benchmark datasets frame by frame
fprintf(1,'Save benchmark datasets frame by frame. \n')
p=0 ; 
for n=1:N
  k=0 ; 
  while p+k<MN && v.fn(p+k+1)==n
    k=k+1 ; 
  end
  if k>0
    % save emitter locations of nth frame 
    xy2=v.xy(p+1:p+k,:) ; 
    filename_xy=strcat('2DGauss_MD_Benchmark_xy_',num2str(n),'.txt') ;
    save(filename_xy,'-ascii','xy2') ;
    % save nth frame
    U16=F(:,:,n) ;
    filename_Frame=strcat('2DGauss_MD_Benchmark_Frame_',num2str(n),'.tif') ;
    imwrite(U16,filename_Frame) ;
  end
  p=p+k ;
end

%% Verify 10th frame of benchmark dataset
n=10 ; 
fprintf(1,'Show frame %d \n',n) ; 
% read emitter locations - ground truth
filename_xy=strcat('2DGauss_MD_Benchmark_xy_',num2str(n),'.txt') ;
xy3=load(filename_xy,'-ascii')' ; 
k=size(xy3,2) ;    % # of activated emitters
% read and save a data frame
filename_Frame=strcat('2DGauss_MD_Benchmark_Frame_',num2str(n),'.tif') ;
U16=imread(filename_Frame);   % read a frame
U=double(U16) ;

% show data frame 
wx=3*Kx/64 ; wy=3*Ky/64 ;     % 3 inch when Kx=64, or 450 pixels with dpi=150
dx=0.04 ; dy=0.04 ; 
PS=[dx/2 dy/2 wx-dx wy-dy] ;  % Positions of subfigures 
figure('Units','inches','Position',[3 2 wx wy],'Color',[1 1 1]) ;
subplot(1,1,1,'Units','inches','Position',PS) ;
show8bimage(U,'Yes','gray','No') ; 
axis off
filename_Frame=strcat('Fig2DGauss_MD_Benchmark_Frame_',num2str(n)) ;
print(filename_Frame,'-dpng')

% show data frame plus emitters
figure('Units','inches','Position',[3 2 wx wy],'Color',[1 1 1]) ;
subplot(1,1,1,'Units','inches','Position',PS) ;
show8bimage(U,'Yes','gray','No') ; hold on
plot(xy(1,:)/Dx+0.5,xy(2,:)/Dy+0.5,'w.','MarkerSize',3.5) ;
plot(xy3(1,:)/Dx+0.5,xy3(2,:)/Dy+0.5,'r.','MarkerSize',3.5) ; hold off
axis off
filename_Frame=strcat('Fig2DGauss_MD_Benchmark_Frame_',num2str(n),'_Emitters') ;
print(filename_Frame,'-dpng')

%% Save benchmark datasets in DeepSTORM format
fprintf(1,'Save benchmark datasets in DeepSTORM format. \n')
% write dataset of emitter locations 
xy3=table(v.No,v.fn,v.eId,v.xy(:,1),v.xy(:,2),v.sg,v.it,v.os,v.bksd, ...
  'VariableNames', {'No','Frame','Emitter','x (nm)','y (nm)','sigma (nm)', ...
  'Intensity (photons)','Offset (photons)','BkgSD (photons)'}) ;
writetable(xy3,'2DGauss_MD_Benchmark_xy.csv') ; 
% write data frame in DeepSTORM format
for n=1:N
  U16=F(:,:,n) ;
  if n==1
    imwrite(U16,'2DGauss_MD_Benchmark_Frame.tif','tif','WriteMode','overwrite','compression','none') ;
  else
    imwrite(U16,'2DGauss_MD_Benchmark_Frame.tif','tif','WriteMode','append','compression','none') ;
  end    
end

%% Benchmark by UGIA-F estimator
% Localization by the UGIA-M and UGIA-F estimators 
fprintf(1,'UGIA-M and UGIA-F estimators: \n') ; 
[xyM,xyF]=Gauss2D_UGIA_MF(sigma,Kx,Ky,Dx,Dy,Dt,Ih,b,G,xy,a) ;
X=zeros(2,sum(Ma_)) ;         % stacked estimated emitter locations
% Show SMLM images reconstructed by UGIA-F estimator 
pF=0 ;                        % # of activated emitters from 1st to nth frames
for n=1:N
  k=Ma_(n) ;                  % # of activated emitters in nth frame
  X(:,pF+1:pF+k)=xyF(:,1:k,n) ;  % No action if Ma_(n)=0
  pF=pF+k ;                   % # of locations in frames 1 to n
end
S=xy ;                        % ground truth
xy_=X' ; 
filename_xy=strcat('2DGauss_MD_xy_UGIA-F.txt') ;
save(filename_xy,'-ascii','xy_') ;
% RMSMD                       
[RMSMD_F,~]=RMSMD(S,X) ;      
% partition, RMSE_P, RMSMD_P
Kai=sum(a,2)' ;               % # of activations for mth emitter in movie
[Xp,Kpi,~]=partitionX(S,X,Kai) ;
RMSEP_F=RMSE_P(S,Xp,Kpi) ;    
RMSMDP_F=RMSMD_P(S,Xp,Kpi) ;  
figure('Units','inches','Position',[3 2 wx wy],'Color',[1 1 1]) ;
subplot(1,1,1,'Units','inches','Position',PS) ; 
show8bimage(zeros(Kx,Ky),'No','gray','No') ; hold on
plot(X(1,:)/Dx+0.5,X(2,:)/Dy+0.5,'w.','MarkerSize',3.5) ; 
% plot([0 Lx Lx 0 0]/Dx,[0 0 Ly Ly 0]/Dy,'w-','MarkerSize',2) ; 
plot([5200 6200]/Dx,[Ly-200 Ly-200]/Dy,'w-',[5200 5200]/Dx,[Ly-200+60 Ly-200-60]/Dy,'w-') ;
plot([6200 6200]/Dx,[Ly-200+60 Ly-200-60]/Dy,'w-') ;
hold off
axis off
text(5300/Dx,(Ly-450)/Dy,'1 {\mu}m','Color','white') ;
text(1*Dx/Dx,2.8*Dy/Dy,'UGIA-F','Color','white') ;
text(1*Dx/Dx,(Ly-2.8*Dy)/Dy,compose('RMSMD=%4.2f (nm) ',RMSMD_F),'Color','white') ;
filename_Frame=strcat('Fig2DGauss_MD_Benchmark_UGIA-F') ;
print(filename_Frame,'-dpng')

% Show SMLM images reconstructed by UGIA-M estimator 
Ia=uint8(zeros(M,1)) ;        % indices of activated emitter of a movie
for n=1:N
  Ia=(Ia | a(:,n)) ;
end                             
pM=sum(Ia) ;                  % # of emitters that were activated at least once in frames 1 to N
X=xyM(:,1:pM,N) ;             % estimated emitter locations
xy_=X' ; 
filename_xy=strcat('2DGauss_MD_xy_UGIA-M.txt') ;
save(filename_xy,'-ascii','xy_') ;
[RMSMD_M,~]=RMSMD(S,X) ;      
KaiM=ones(1,M) ;
[Xp,Kpi,Ip]=partitionX(S,X,KaiM) ;
RMSEP_M=RMSE_P(S,Xp,Kpi) ;    
RMSMDP_M=RMSMD_P(S,Xp,Kpi) ;  
figure('Units','inches','Position',[3 2 wx wy],'Color',[1 1 1]) ;
subplot(1,1,1,'Units','inches','Position',PS) ; 
show8bimage(zeros(Kx,Ky),'Yes','gray','No') ; hold on
plot(xyM(1,1:pM,N)/Dx+0.5,xyM(2,1:pM,N)/Dy+0.5,'w.','MarkerSize',3.5) ; 
% plot([0 Lx Lx 0 0]/Dx,[0 0 Ly Ly 0]/Dy,'w-','MarkerSize',2) ; 
plot([5200 6200]/Dx,[Ly-200 Ly-200]/Dy,'w-',[5200 5200]/Dx,[Ly-200+60 Ly-200-60]/Dy,'w-') ;
plot([6200 6200]/Dx,[Ly-200+60 Ly-200-60]/Dy,'w-') ;
hold off
axis off
text(5300/Dx,(Ly-450)/Dy,'1 {\mu}m','Color','white') ;
text(1*Dx/Dx,2.8*Dy/Dy,'UGIA-M','Color','white') ;
text(1*Dx/Dx,(Ly-2.8*Dy)/Dy,compose('RMSMD=%4.2f (nm) ',RMSMD_M),'Color','white') ;
filename_Frame=strcat('Fig2DGauss_MD_Benchmark_UGIA-M') ;
print(filename_Frame,'-dpng')

%% For leaderboard: save (i) ground-truth emitter locations ; (ii) Kai
xy0=xy' ;                     % ground truth emitter locaitons
filename_xy0=strcat('2DGauss_MD_Benchmark_xy0.txt') ;
save(filename_xy0,'-ascii','xy0') ;
Kai=Kai' ;                    % # of activations for each emitter
filename_Kai=strcat('2DGauss_MD_Benchmark_Kai.txt') ;
save(filename_Kai,'-ascii','Kai') ; 
% UGIA-F, UGIA-M
fprintf(1,'UGIA-F: (RMSMD RMSMD-P RMSE-P) = (%4.2f %4.2f %4.2f) (nm) \n',RMSMD_F,RMSMDP_F,RMSEP_F) ;
fprintf(1,'UGIA-M: (RMSMD RMSMD-P RMSE-P) = (%4.2f %4.2f %4.2f) (nm) \n',RMSMD_M,RMSMDP_M,RMSEP_M) ;
