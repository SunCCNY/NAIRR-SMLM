%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% NAIRR-SMLM: AS3D_LD_Test.m 
% . AS            - PSF - astigmatic
% . 3D            - 3D emitter locations 
% . LD            - low density of emitters
% . Test          - test dataset
% . Location      - emitters are located on a helix 
% . Markov        - emitters activated frame by frame with a Markov chain [1]
%
% References
% [1] Y. Sun, "Localization precision of stochastic optical localization 
% nanoscopy using single frames," J. Biomed. Optics, vol. 18, no. 11, pp. 
% 111418-14, Oct. 2013.
% [2] Y. Sun, "Root mean square minimum distance as a quality metric for
% stochastic optical localization nanoscopy images," Sci. Reports, vol. 8, 
% no. 1, pp. 17211, Nov. 2018.
% [3] Y. Sun, "Information sufficient segmentation and signal-to-noise 
% ratio in stochastic optical localization nanoscopy," Optics Letters, 
% vol. 45, no. 21, pp. 6102-6105, Nov. 1, 2020. 
% [4] Y. Sun, "Markov chain models of emitter activations in single molecule 
% localization microscopy," Optics Express, vol. 32, no. 19, pp. 33779-33794, 
% Sept. 2024. 
% [5] M. Sun and Y. Sun, "Information sufficient segmentation and 
% signal-to-noise ratio for 3D astigmatism stochastic optical localization 
% nanoscopy," Electr. Letters, vol. 58, no. 2, Oct. 28, pp. 58-60, 2021.
% 
% Yi Sun
% Electrical Engineering Department
% The City College of City University of New York
% E-mail: ysun@ccny.cuny.edu
% 11/24/2019, 04/01/2020, 12/18/2020, 12/23/2024, 1/23/2025
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear
%% Emitter density: choose one of them
eD=120 ;                      % low - emitter density (emitters/um^2)
N=1000 ;                      % number of data frames

%% Intialization 
rng('default') ; 
key=0 ;                       % key for random number generators
key=key+floor(eD) ; 
rng(key) ; 

%% Optical system: 3D astigmatic 
c=205 ;
d=290 ;                       % depth of microscope
sigmax0=280/2 ; Ax=0.05 ; Bx=0.03 ;   % nm
sigmay0=270/2 ; Ay=-0.01 ; By=0.02 ;	% 

%% Frame: sample is in [0,Lx]x[0,Ly]x[-Lz,Lz]
Kx=64 ; Ky=64 ;               % frame size in pixel
Dx=100 ; Dy=100 ;             % pixel size of cammera in nm
Lx=Kx*Dx ; Ly=Ky*Dy ;         % FOV: [0,Lx]x[0,Ly]
Lz=400 ;                      % 2 x Lz = axial depth in nm

%% Emitter intensity and signal to noise ratio
Dt=0.01 ;                     % sec, frame time (1/Dt is frame rate) 
Ih=240000 ;                   % average number of detected photons per emitter per second
DtIh=Dt*Ih ;                  % photon count per frame per emitter 
% 'medium SNR'                % 
b=0.3 ;                       % mean of Poisson noise (photons/s/nm^2)
G=0.2 ;                       % variance of Gaussian noise (photons/s/nm^2) 
rp=Ih/b ;                     % 800000 (nm^2/emitter) 
rg=Ih/G ;                     % 1200000 (nm^2/emitter) 
r=rp*rg/(rp+rg) ;             % 480000 (nm^2/emitter) 
mu=5 ;                        % mean of Gaussian noise (photons/s/nm^2)
Coff=mu*Dt*Dx*Dy ;            % Coff=500 photons/pixel; Camera offset in effect

% calculate SNR by Ref. [5] 
z0=0 ;                        % consider z0=0 only 
sigmax_z0= ...                % 172.8791 nm
  sigmax0*(1+(z0+c).^2/d^2+Ax*(z0+c).^3/d^3+Bx*(z0+c).^4/d^4).^0.5 ;
sigmay_z0= ...                % 165.7935 nm
  sigmay0*(1+(z0-c).^2/d^2+Ay*(z0-c).^3/d^3+By*(z0-c).^4/d^4).^0.5 ;
SNR=10*log10(r) ...           % 1.2193 (dB) 
  -10*log10(sigmax_z0*sigmay_z0)-11.02 ;

%% Emitter locations - ground truth
fprintf(1,'Emitter locations: \n') ;
M=400 ;               % number of emitters
phi=0.1 ; beta=9+0.5*rand ;  % helix parameters 
xy1=zeros(3,M) ; 
J=zeros(1,M) ; 
m=1 ; J(m)=2 ;        % 1st emitter locaiton
xy1(:,m)=[beta*J(m)*cos(phi*J(m))  
          beta*J(m)*sin(phi*J(m))
          -Lz+(m-0.5)*(1.8*Lz/M)] ; 
for m=2:M
  if mod(m,10)==0||m==1
    fprintf(1,'M=%3d m=%3d \n',M,m) ;
  end
  syms t0
  St=vpasolve((beta*t0*cos(phi*t0)-xy1(1,m-1))^2+(beta*t0*sin(phi*t0)-xy1(2,m-1))^2==eD^2,t0,J(m-1)+0.1) ;
  J(m)=St ;
  xy1(:,m)=[beta*J(m)*cos(phi*J(m)) 
            beta*J(m)*sin(phi*J(m))
            -Lz+(m-0.5)*(1.8*Lz/M)] ; 
end
phi_=2*pi*rand ;            % random initial position in lateral plane
xy_=[cos(phi_) -sin(phi_) 
     sin(phi_) cos(phi_)]*xy1(1:2,:)+2*randn(2,1) ; 
xy0=[(max(xy_(1,:))+min(xy_(1,:)))/2 ; (max(xy_(2,:))+min(xy_(2,:)))/2] ;
xy_=xy_-xy0+[Lx/2 ; Ly/2] ; % adjust to frame center in lateral plane
xyz=[xy_ ; xy1(3,:)] ;      % ground truth emitter locaitons 

%% Show and save 3D emitter locations 
fprintf(1,'Figure of emitters \n') ; 
wx=3 ; wy=0.8*wx ; dx=0.62 ; dy=-0.05 ; 
PS=[dx/2+0.04 dy/2+0.22 wx-dx wy+dy] ;    % Positions of subfigures 
figure('Units','inches','Position',[3 4 wx wy],'Color',[1 1 1]) ;
subplot(1,1,1,'Units','inches','Position',PS) ;
plot3(xyz(1,:)/1e3,xyz(2,:)/1e3,xyz(3,:)/1e3,'k.','MarkerSize',3) 
axis([0 Lx 0 Ly -Lz Lz]/1e3)
grid on
xlabel('x ({\mu}m)','FontSize',6)
ylabel('y ({\mu}m)','FontSize',6)
zlabel('z ({\mu}m)','FontSize',6)
set(gca,'XTick',[0 1 2 3 4 5 6]) ;
set(gca,'XTickLabel',[0 1 2 3 4 5 6]) ;
set(gca,'YTick',[0 1 2 3 4 5 6]) ;
set(gca,'YTickLabel',[0 1 2 3 4 5 6]) ;
set(gca,'ZTick',[-400 -200 0 200 400]/1e3) ;
set(gca,'ZTickLabel',[-400 -200 0 200 400]/1e3) ;
set(gca,'FontSize',6) ;
filename_Frame=strcat('Fig3DAS_LD_Test_xyz') ;
print(filename_Frame,'-dpng')

%% Emitter activations parameters: Continuous illumination, state 0, 1, 2 
t0=0.60 ;                     % mean of T0 in sec
p0=exp(-Dt/t0) ;              % 0.9835, probability to retain state 0 in Dt
t1=0.015 ;                    % mean of T1 in sec
p1=exp(-Dt/t1) ;              % 0.5134, probability to retain state 1 in Dt
t=10.0 ;                      % mean of T 
p=exp(-Dt/t) ;                % 0.9988, probability being photoactivatable in Dt
% transition probabilities
r00=p0*p ;                    % 0.9825, Trans. prob. from state 0 to 0
r10=(1-p0)*p ;                % 0.0165, Trans. prob. from state 0 to 1
r20=1-p ;                     % 0.0009995, Trans. prob. from state 0 to 2
r01=(1-p1)*p ;                % 0.4861, Trans. prob. from state 1 to 0
r11=p1*p ;                    % 0.5129, Trans. prob. from state 1 to 1
r21=1-p ;                     % 0.009995, Trans. prob. from state 1 to 2

%% Generate states of all emitters in data movie 
[ca,~,h1]=emActMarkovContinue(t,t1,t0,Dt,N,M) ;
                          % h1=0.0329
a=(ca==1) ;               % a(m,n)=1 if activated; a(m,n)=0 otherwise  
                          % sum(sum(a')==0): # of emitters never activated 
Ma_=sum(a) ;              % number of activated emitters in nth frame
% compare formulas and estimates 
Np_=sum(sum(ca~=2))/M ;   % 395.07, average # of photoactivatable frames per emitter
Nae_=sum(Ma_)/M ;         % 13.02, average # of activated frames per emitter in movie
Na_=M*Nae_ ;              % 5208, total # of activated frames for all emitters in movie 
Maf_=sum(Ma_)/N ;         % 10.42, average number of activated emitters per frame

%% Stack activated emitters in each frame
xyzActive=zeros(3,M,N) ;  % activated emitter locations in nth frame
for n=1:N
  if Ma_(n)>0
    k=0 ; 
    for m=1:M
      if a(m,n)
        k=k+1 ;
        xyzActive(:,k,n)=xyz(:,m) ;
      end
      if k==Ma_(n), break ; end
    end
  end
end

%% generate datasets of xyz and frames
fprintf(1,'Generate datasets. \n')
MN=sum(sum(a)) ;              % total # of emitter activations in movie
v.id=zeros(MN,1) ;            % id
v.fn=zeros(MN,1) ;            % frame index
v.xyz=zeros(MN,3) ;           % emitter coordinates
v.sgx_z0=sigmax_z0*ones(MN,1) ;  % sigma in nm
v.sgy_z0=sigmay_z0*ones(MN,1) ;  % sigma in nm
v.it=DtIh*ones(MN,1) ;        % intensity (photons)
v.os=Coff*ones(MN,1) ;        % offset 
v.bksd=(b+G)*ones(MN,1) ;     % standard deviation of background noise 
F=uint16(zeros(Ky,Kx,N)) ;    % all frames in movie
p=0 ; 
for n=1:N
  % Generate emitter locations of nth frame - ground truth
  k=Ma_(n) ;                  % # of activated emitters in nth frame
  if k>0
    xyz2=xyzActive(:,1:k,n)' ;
    v.id(p+1:p+k)=(p+1:p+k)' ;
    v.fn(p+1:p+k)=n ;
    v.xyz(p+1:p+k,:)=xyz2 ;   % ground truth
    % Generate a data frame
    U=AS3D_Frame(c,d,sigmax0,Ax,Bx,sigmay0,Ay,By,Kx,Ky,Dx,Dy,Dt,Ih,b,mu,G,xyz2') ;
    F(:,:,n)=uint16(U) ;
    p=p+k ; 
  end
end

%% Save test datasets frame by frame
fprintf(1,'Save test datasets frame by frame. \n')
p=0 ; 
for n=1:N
  k=0 ; 
  while p+k<MN && v.fn(p+k+1)==n
    k=k+1 ; 
  end
  if k>0
    % save emitter locations of nth frame 
    xyz3=v.xyz(p+1:p+k,:) ; 
    filename_xyz=strcat('3DAS_LD_Test_xyz_',num2str(n),'.txt') ;
    save(filename_xyz,'-ascii','xyz3') ;
    % save nth frame
    U16=F(:,:,n) ;
    filename_Frame=strcat('3DAS_LD_Test_Frame_',num2str(n),'.tif') ;
    imwrite(U16,filename_Frame) ;
  end
  p=p+k ;
end

%% Verify 10th frame of test dataset
n=10 ; 
fprintf(1,'Show frame %d \n',n) ; 
% read emitter locations - ground truth
filename_xyz=strcat('3DAS_LD_Test_xyz_',num2str(n),'.txt') ;
xyz3=load(filename_xyz,'-ascii')' ; 
k=size(xyz3,2) ;              % # of activated emitters
% read and save a data frame
filename_Frame=strcat('3DAS_LD_Test_Frame_',num2str(n),'.tif') ;
U16=imread(filename_Frame);   % read a frame
U=double(U16) ;

% show data frame 
wx=3*Kx/64 ; wy=3*Ky/64 ;     % 3 inch when Kx=64, or 450 pixels with dpi=150
dx=0.04 ; dy=0.04 ; 
PS=[dx/2 dy/2 wx-dx wy-dy] ;  % Positions of subfigures 
figure('Units','inches','Position',[3 2 wx wy],'Color',[1 1 1]) ;
subplot(1,1,1,'Units','inches','Position',PS) ;
show8bimage(U,'Yes','gray','No') ; 
axis off
filename_Frame=strcat('Fig3DAS_LD_Test_Frame_',num2str(n)) ;
print(filename_Frame,'-dpng')

% show data frame plus emitters
figure('Units','inches','Position',[3 2 wx wy],'Color',[1 1 1]) ;
subplot(1,1,1,'Units','inches','Position',PS) ;
show8bimage(U,'Yes','gray','No') ; hold on
plot(xyz(1,:)/Dx+0.5,xyz(2,:)/Dy+0.5,'w.','MarkerSize',3.5) ;
plot(xyz3(1,:)/Dx+0.5,xyz3(2,:)/Dy+0.5,'r.','MarkerSize',3.5) ; hold off
axis off
filename_Frame=strcat('Fig3DAS_LD_Test_Frame_',num2str(n),'_Emitters') ;
print(filename_Frame,'-dpng')

%% Save test datasets in DeepSTORM format
fprintf(1,'Save test datasets in DeepSTORM format. \n')
% write dataset of emitter locations 
xyz3=table(v.id,v.fn,v.xyz(:,1),v.xyz(:,2),v.xyz(:,3),v.sgx_z0,v.sgy_z0,v.it,v.os,v.bksd, ...
  'VariableNames', {'Id','Frame','x (nm)','y (nm)','z (nm)','sigmax_z0 (nm)','sigmay_z0 (nm)', ...
  'Intensity (photons)','Offset (photons)','BkgSD (photons)'}) ;
writetable(xyz3,'3DAS_LD_Test_xyz.csv') ; 
% write data frame in DeepSTORM format
for n=1:N
  U16=F(:,:,n) ;
  if n==1
    imwrite(U16,'3DAS_LD_Test_Frame.tif','tif','WriteMode','overwrite','compression','none') ;
  else
    imwrite(U16,'3DAS_LD_Test_Frame.tif','tif','WriteMode','append','compression','none') ;
  end    
end
